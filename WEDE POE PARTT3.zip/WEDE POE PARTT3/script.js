document.addEventListener('DOMContentLoaded', () => {
    // Alert message when the "Sign In" link is clicked
    const signInLink = document.querySelector('a[href="sign up&in.html"]');
    if (signInLink) {
      signInLink.addEventListener('click', (event) => {
        event.preventDefault();
        alert('Sign In link clicked!');
        // Optionally, you could redirect after the alert:
        // window.location.href = signInLink.href;
      });
    }
  
    // Hover effect for the "About Us" image
    const aboutImage = document.querySelector('img[alt="About Us image"]');
    if (aboutImage) {
      aboutImage.addEventListener('mouseover', () => {
        aboutImage.style.transform = 'scale(1.1)';
        aboutImage.style.transition = 'transform 0.3s ease';
      });
  
      aboutImage.addEventListener('mouseout', () => {
        aboutImage.style.transform = 'scale(1)';
      });
    }
});
// script.js

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("contactForm");
  
    form.addEventListener("submit", (e) => {
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const message = document.getElementById("message").value.trim();
      const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  
      if (!name || !email || !message) {
        alert("All fields are required.");
        e.preventDefault();
      } else if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        e.preventDefault();
      }
    });
  });
  // _scripts/script.js

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("homepageContact");
  
    form.addEventListener("submit", (e) => {
      const name = document.getElementById("contactName").value.trim();
      const email = document.getElementById("contactEmail").value.trim();
      const message = document.getElementById("contactMsg").value.trim();
      const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  
      if (!name || !email || !message) {
        alert("All fields are required.");
        e.preventDefault();
      } else if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        e.preventDefault();
      }
    });
  });
  // _scripts/script.js

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("homepageContact");
  
    form.addEventListener("submit", (e) => {
      const name = document.getElementById("contactName").value.trim();
      const email = document.getElementById("contactEmail").value.trim();
      const message = document.getElementById("contactMsg").value.trim();
      const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  
      if (!name || !email || !message) {
        alert("All fields are required.");
        e.preventDefault();
      } else if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        e.preventDefault();
      }
    });
  });
  // _scripts/script.js

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("paymentForm");
  
    form.addEventListener("submit", (e) => {
      const name = document.getElementById("cardName").value.trim();
      const cardNumber = document.getElementById("cardNumber").value.trim();
      const cvv = document.getElementById("cvv").value.trim();
      const cardPattern = /^\d{16}$/;
      const cvvPattern = /^\d{3}$/;
  
      if (!name || !cardNumber || !cvv) {
        alert("Please fill out all fields.");
        e.preventDefault();
      } else if (!cardPattern.test(cardNumber)) {
        alert("Card number must be 16 digits.");
        e.preventDefault();
      } else if (!cvvPattern.test(cvv)) {
        alert("CVV must be 3 digits.");
        e.preventDefault();
      }
    });
  });
  // === Cart Placeholder ===
  const cartLink = document.querySelector(".cart a");
  if (cartLink) 
    cartLink.addEventListener("click", (e) => {
      e.preventDefault();
      alert("Cart functionality coming soon! 🛒");
    });
    // _scripts/script.js

document.addEventListener("DOMContentLoaded", () => {
    // Sign In Form
    const signinForm = document.getElementById("SigninForm");
    if (signinForm) {
      signinForm.addEventListener("submit", (e) => {
        const email = document.getElementById("signinEmail").value.trim();
        const password = document.getElementById("signinPassword").value.trim();
  
        if (!email || !password) {
          alert("Please fill in both email and password to sign in.");
          e.preventDefault();
        }
      });
    }
  
    // Sign Up Form
    const signupForm = document.getElementById("SignupForm");
    if (signupForm) {
      signupForm.addEventListener("submit", (e) => {
        const email = document.getElementById("signupEmail").value.trim();
        const password = document.getElementById("signupPassword").value.trim();
  
        if (!email || !password) {
          alert("Please fill in both email and password to sign up.");
          e.preventDefault();
        } else if (password.length < 6) {
          alert("Password must be at least 6 characters.");
          e.preventDefault();
        }
      });
    }
  });



